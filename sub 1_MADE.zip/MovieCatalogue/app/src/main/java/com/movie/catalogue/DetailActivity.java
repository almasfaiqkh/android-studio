package com.movie.catalogue;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class DetailActivity extends AppCompatActivity {
    TextView name, description;
    ImageView imgDetail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);



        Film film;
        film = getIntent().getParcelableExtra("data");

        name = findViewById(R.id.name);
        String text;
        text = film.getName();
        name.setText(text);


        description = findViewById(R.id.description);
        String text2;
        text2 = film.getDescription();
        description.setText(text2);


        int Image;
        Image = film.getPhoto();
        imgDetail = findViewById(R.id.imgDetail);
        imgDetail.setImageResource(Image);
    }
}